package ar.org.centro8.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import ar.org.centro8.entities.Motocicleta;
import ar.org.centro8.entities.Automovil;
import ar.org.centro8.entities.Vehiculo;

public class VehiculoTest {

        // Marca: Peugeot // Modelo: 206 // Puertas: 4 // Precio: $200.000,00
        // Marca: Honda // Modelo: Titan // Cilindrada: 125c // Precio: $60.000,00
        // Marca: Peugeot // Modelo: 208 // Puertas: 5 // Precio: $250.000,00
        // Marca: Yamaha // Modelo: YBR // Cilindrada: 160c // Precio: $80.500,50

        public static void main(String[] args) {
                List<Vehiculo> list = new ArrayList();
                list.add(new Automovil("Peugeot", "206", 4, 200000.00));
                list.add(new Motocicleta("Honda", "Titan", "125c", 60000.00));
                list.add(new Automovil("Peugeot", "208", 5, 250000.00));
                list.add(new Motocicleta("Yamaha", "YBR", "160c", 80500.50));
                list.stream().forEach(System.out::println);

                System.out.println();
                System.out.println("****************************************************************");

                // Vehículo más caro: Peugeot 208
                double precioMaximo = list
                                .stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();

                System.out.println("Vehículo más caro:");
                list
                                .stream()
                                .filter(v -> v.getPrecio() == precioMaximo)
                                .forEach(System.out::println);

                System.out.println();

                // Vehículo más barato: Honda Titan
                double precioMinimo = list
                                .stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
                System.out.println("Vehículo más barato:");
                list
                                .stream()
                                .filter(v -> v.getPrecio() == precioMinimo)
                                .forEach(System.out::println);

                System.out.println();

                // Vehículo que contiene en el modelo la letra ‘Y’: Yamaha YBR $80.500,50
                System.out.println("Vehículo que contiene en el modelo la letra 'Y':");

                list
                                .stream()
                                .filter(p -> p.getModelo().toLowerCase().startsWith("y".toLowerCase()))

                                .forEach(System.out::println);

                System.out.println();
                System.out.println("****************************************************************");

                // Vehículos ordenados por precio de mayor a menor:
                // Peugeot 208, Peugeot 206,
                // Yamaha YBR, Honda Titan.
                System.out.println("Vehículos ordenados por precio de mayor a menor:");
                list
                                .stream()
                                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                                .forEach(System.out::println);

                System.out.println();
                System.out.println("****************************************************************");

                // Vehículos ordenados por orden natural (marca, modelo, precio):
                // Marca: Honda // Modelo: Titan // Cilindrada: 125c // Precio: $60.000,00
                // Marca: Peugeot // Modelo: 206 // Puertas: 4 // Precio: $200.000,00
                // Marca: Peugeot // Modelo: 208 // Puertas: 5 // Precio: $250.000,00
                // Marca: Yamaha // Modelo: YBR // Cilindrada: 160c // Precio: $80.500,50

                System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
                list
                                .stream()
                                .sorted(Comparator.comparing(Vehiculo::getMarca))
                                .forEach(System.out::println);

                System.out.println();
                System.out.println("-----FIN-----");
                System.out.println();
        }

}
