package ar.org.centro8.entities;

public class Motocicleta extends Vehiculo {
    private String cilindrada;

    public Motocicleta(String marca, String modelo, String cilindrada, double precio) {
        super(marca, modelo, precio);

        this.cilindrada = cilindrada;

    }

    @Override
    public String toString() {
        return "Motocicleta [marca=" + getMarca() + ", modelo=" + this.getModelo() + ", cilindrada=" + cilindrada
                + ", precio=" + this.getPrecio() + "]";
    }

    public String getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(String cilindrada) {
        this.cilindrada = cilindrada;
    }

}